import os
import argparse
import subprocess


def process(input_dir, output_dir):
    os.makedirs(output_dir, exist_ok=True)

    input_files = [f for f in os.listdir(input_dir) if os.path.isfile(os.path.join(input_dir, f))]

    for input_file in input_files:
        input_path = os.path.join(input_dir, input_file)

        base_name = os.path.splitext(input_file)[0]
        output_A = os.path.join(output_dir, f'{base_name}_lum.tif')
        output_B = os.path.join(output_dir, f'{base_name}_mask.tif')
        output_C = os.path.join(output_dir, f'{base_name}_list.txt')
        output_D = os.path.join(output_dir, f'{base_name}_mark.tif')
        output_E = os.path.join(output_dir, f'{base_name}_tab.csv')
        output_F = os.path.join(output_dir, f'{base_name}_movl.tif')

        subprocess.run(['!python3', 'Detection/result.py',\
                        input_path, output_A, output_B, output_C, output_D, output_E, output_F])


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Batch process images using result.py.')
    parser.add_argument('input_dir', type=str, help='Directory containing input images')
    parser.add_argument('output_dir', type=str, help='Directory for output files')

    args = parser.parse_args()

    process(args.input_dir, args.output_dir)
